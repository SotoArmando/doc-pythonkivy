#!/usr/bin/env python
# -*- coding: utf-8 -*-

import json
import math
import os
import os.path
import sys
import threading
import time
from threading import *
from threading import Timer

import kivy
import requests
from kivy.adapters.listadapter import ListAdapter
from kivy.adapters.models import SelectableDataItem
from kivy.adapters.simplelistadapter import SimpleListAdapter
from kivy.animation import Animation
from kivy.app import App
from kivy.base import runTouchApp
from kivy.clock import Clock, mainthread
from kivy.core.window import Window
from kivy.effects.opacityscroll import OpacityScrollEffect
from kivy.effects.scroll import ScrollEffect
from kivy.garden.mapview import MapMarker, MapSource, MapView, MarkerMapLayer
from kivy.graphics import *
from kivy.graphics.instructions import InstructionGroup
from kivy.metrics import MetricsBase, dp
from kivy.parser import parse_color
from kivy.properties import (BooleanProperty, ListProperty, NumericProperty,
                             ObjectProperty, OptionProperty, StringProperty)
from kivy.resources import resource_add_path
from kivy.uix.accordion import Accordion, AccordionItem
from kivy.uix.anchorlayout import AnchorLayout
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.bubble import Bubble
from kivy.uix.button import Button
from kivy.uix.checkbox import CheckBox
from kivy.uix.dropdown import DropDown
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.image import AsyncImage, Image
from kivy.uix.label import Label
from kivy.uix.listview import (CompositeListItem, ListItemButton,
                               ListItemLabel, ListView)
from kivy.uix.popup import Popup
from kivy.uix.relativelayout import RelativeLayout
from kivy.uix.scatter import Scatter
from kivy.uix.screenmanager import (FadeTransition, FallOutTransition,
                                    NoTransition, RiseInTransition, Screen,
                                    ScreenManager, SlideTransition,
                                    SwapTransition, WipeTransition)
from kivy.uix.scrollview import ScrollView
from kivy.uix.stencilview import StencilView
from kivy.uix.textinput import TextInput
from kivy.uix.togglebutton import ToggleButton
from kivy.uix.widget import Widget
from kivy.utils import get_color_from_hex, get_hex_from_color, platform
from plyer import gps

from utils import NavigationDrawer

if platform == "android":

    from jnius import cast
    from jnius import autoclass
    MediaPlayer = autoclass('android.media.MediaPlayer')
    AudioManager = autoclass('android.media.AudioManager')

else:
    print(platform, "PLATAFORMA")







C1 = "[color=#13C0C7]"
C2 = "[color=#404040]"
C3 = "[color=#ff3333]"
C4 = "[color=#000000]"
metrics = MetricsBase()
android_dpi = metrics.density
asset_dpi = [.75,1.,1.5,2.,3.,4.]
asset_dpi2 = ['ldpi','mdpi','hdpi','xhdpi','xxhdpi','xxxhdpi']
patch = os.path.dirname(os.path.abspath(__file__))

color = patch + '/hud/colors/'
sound = patch + '/sounds/'
hud = patch + '/hud/'

asset = ''
for i in asset_dpi:
    if android_dpi == i:
        asset = patch + '/asset/drawable-'+str(asset_dpi2[asset_dpi.index(i)])+'/'

Window.clearcolor = (1,1,1,1)
Window.size = (360,640)
#Window.size = (720,1242)




class ImageButton(ButtonBehavior, AsyncImage): pass

class InterfaceManager(RelativeLayout):
    def __init__(self, **kwargs):
        super(InterfaceManager, self).__init__(**kwargs)
        self.dimstate2 = True
        self.Contador_state = 1
        self.Tiempo = float(0)
        self.mainparent()
        self.screen1()
        self.activar_state()
        self.dimstate1 = False
        
        
    def Activar(self):
        #from kivy.core.audio import SoundLoader
        #sound = SoundLoader.load('sounds/applause.wav')
        #sound.play()

       
        def setfalse(self): 
            self.dimstate2 = False

        if self.dimstate2 == False: 
            self.dimstate2 = True
            Clock.schedule_interval(lambda x: setfalse, 5.0)
        else:
            mPlayer = MediaPlayer()
            mPlayer.setDataSource(sound + 'default.wav')
            mPlayer.prepare()
            mPlayer.start()

    def mainparent(self):
        self.Mainparent = ScreenManager()
        self.add_widget(self.Mainparent)

    def TextTimerwidget(self):
        parent = GridLayout(rows = 1,size_hint_y = None, height = '100dp')
        l = ['0','0',':','0','0',':','0','0']
        self.l_buttons = []
        parent.add_widget(Label())
        for i in l:
            textletter = Button(text = C4+i,markup = True, background_normal = color+"16.png",background_down = color+"16.png", font_size = '60sp', size_hint_x = None, width = '35dp')
            parent.add_widget(textletter)
            self.l_buttons.append(textletter)
        parent.add_widget(Label())
        return parent

    def screen1(self):
        self.Screen1 = Screen()
        self.Mainparent.add_widget(self.Screen1)

        self.Screen1_parent = GridLayout(cols = 1)
        self.Screen1.add_widget(self.Screen1_parent)

        self.Screen1_parent.add_widget(self.Topmenu())
        
        self.TextTimerV2 = Button(size_hint_y = None, height = '50dp' , font_size = '20sp',markup = True, text = C4+"0 Horas 0 Minutos y 0 Segundos", background_normal = color + "16.png")
        self.Screen1_parent.add_widget(self.TextTimerwidget())
        self.Screen1_parent.add_widget(self.TextTimerV2)

        self.Buttons_parent = GridLayout(size_hint_y = None , height = "64dp", rows = 1)
        self.Buttons_parent.add_widget(Label())
        Buttons_parent_backgrounds = ['hud15','hud14','hud16']

        for i in range(3): 
            Buttonx = ImageButton(size_hint_x = None , width = "64dp", source = asset + Buttons_parent_backgrounds[i] + '.png')
            Buttonx_parent = Scatter()
            Buttonx_parentparent = GridLayout(cols =1, size_hint_y = None, size_hint_x = None, width = '64dp')
            Buttonx_parent.add_widget(Buttonx)
            Buttonx_parentparent.add_widget(Buttonx_parent)
            Buttonx.bind(on_press = lambda x:self.Animatesize(x.parent))
            self.Buttons_parent.add_widget(Buttonx_parentparent)
            if i == 0: Buttonx.bind(on_release = lambda x: self.activar_state())
            if i == 1: Buttonx.bind(on_release = lambda x: self.ReiniciarTiempo(x))
            if i == 2: Buttonx.bind(on_release = lambda x: self.ReducirTiempo(self.Tiempo))
            

        self.Buttons_parent.add_widget(Label())
        self.Screen1_parent.add_widget(self.Buttons_parent)

        self.RootControls = GridLayout(rows = 1, size_hint_y = None , height = '64dp')
        self.RootControl1 = ImageButton(size_hint_x = None , width = '64dp', source = asset + "Path 2.png")
        self.RootControl2 = ImageButton(size_hint_x = None , width = '64dp', source = asset + "Path 1.png")
        self.RootControls.add_widget(self.RootControl1)
        self.RootControls.add_widget(Label())
        self.RootControls.add_widget(self.RootControl2)
        self.Screen1_parent.add_widget(self.RootControls)
        def RootControls_release(n):
            if n == 0: 
                self.Controls.transition = SlideTransition(direction = "left")
                self.Controls.current = self.Controls.next()
            else: 
                self.Controls.transition = SlideTransition(direction = "right")
                self.Controls.current = self.Controls.previous()

        self.Controls = ScreenManager(size_hint_y = None , height = '64dp')
        self.RootControl1.bind(on_release = lambda x: RootControls_release(1))
        self.RootControl2.bind(on_release = lambda x: RootControls_release(0))
        self.Screen1_parent.add_widget(self.Controls)
        NewControls = {0: ["30S"," 60S"," 180S"], 1: ["180S"," 300S","900S"], 2: [" 900S","1800S","3600S"]}
        NewControls_images = {0: ["Group 4","Group 5","Group 6"], 1: ['Group 6','Group 8','Group 9'], 2: ['Group 1','Group 2','Group 3']}
        
        for N in range(3):
            Control_Screen = Screen(name = "Control" + str(N))
            Control_Screen_parent = GridLayout(rows = 1)
            Control_Screen.add_widget(Control_Screen_parent)
            Control_Screen_parent.add_widget(Label())
            ControlButtonsArray = []
            for x in NewControls[N]:
                index = NewControls[N].index(x)

                Controlbutton = Button(border = [0,0,0,0],font_size = '26sp',markup = True,text_size = (5,5),text = x, background_down = asset + NewControls_images[N][index] + '.png', background_normal = asset + NewControls_images[N][index] + '.png',size_hint_y = 1, height = '64dp',  size_hint_x = 1 , width = '64dp')
                Controlbutton_parent = Scatter(do_translation_y=False,do_translation_x=False)
                Controlbutton_parent.add_widget(Controlbutton)
                Controlbutton_parentparent = GridLayout(size_hint_x = None ,height = '64dp',size_hint_y = None, width = '64dp', cols = 1)
                Controlbutton_parentparent.add_widget(Controlbutton_parent)
                
                
                Controlbutton.bind(on_press = lambda x: self.AumentarTiempo(int(x.text[:-1]),x))
                Control_Screen_parent.add_widget(Controlbutton_parentparent)
                if index == 2: pass
                else:Control_Screen_parent.add_widget(Label(size_hint_x = None, width = 30))

            Control_Screen_parent.add_widget(Label())

            self.Controls.add_widget(Control_Screen)
        
    def ReiniciarTiempo(self,button):
        #self.Animatesize(button.parent)
        self.Tiempo = self.TimeState
        self.CalcularTiempo(1)
        if self.Contador_state == 1: self.Contador_state *= -1      

    def ReducirTiempo(self,Plus):
        C1 = "[color=#000000]"
        if Plus == self.Tiempo:
            self.dimstate1 = True
        self.Tiempo -= Plus
        self.CalcularTiempo(1)
        if self.Contador_state == 1: self.Contador_state *= -1
        
        threading.Timer(1, self.activar_contar).cancel()
        Letras = ["0","0",":","0","0",":","0","0"]
        for i in self.l_buttons:
            i.text = C1+Letras[self.l_buttons.index(i)]

    def Topmenu(self):
        
        choose = ScrollView(bar_margin = 0,size_hint_y = None,height = '120dp' ,do_scroll_y = False, do_scroll_x = True ,scroll_x = 0.5,bar_color = [0,0,0,.6],bar_inactive_color = [.7,.7,.7,.2],bar_width = 3, bar_pos_x = "top")
        chooseroot_root = RelativeLayout(size_hint_y = 1, size_hint_x = None, width = Window.width*3)
        chooseroot = GridLayout(rows = 1, size_hint_y = 1, size_hint_x = 1, spacing = 5)
        chooseroot_root.add_widget(chooseroot)
        choose.add_widget(chooseroot_root)
        self.medio = Image(source = asset + "clock.png", size_hint = (None,None), size = ('24dp','24dp'), pos = (0,dp(100)-dp(24)))
        chooseroot_root.add_widget(self.medio)
    
        imgset = ["bacon","bread","coffeex","fried-egg","meat","toaster","tea","teapot","pizza","shrimp"]
        
        for i in range(10):  
            if i == 0:
                chooseroot.add_widget(Image(source = hud+"None.png",allow_stretch = True, keep_ratio = False,size_hint_x = None, width = '64dp')) 
            self.container = GridLayout(cols = 1, size_hint = (1,1))
            dpix = (dp(120)/2) - (dp(64)/2) 
            image = ImageButton(source = asset +imgset[i]+".png",size_hint = (None,None),width = '64dp', height = '64dp', allow_stretch = True,  keep_ratio = True,  pos = (0,dpix) )
            self.imagescatter = Scatter(scale = 1,do_translation_y=False,do_translation_x=False,source = asset +imgset[i],size_hint = (1,1) , allow_stretch = True,  keep_ratio = True)
            
            image.bind(on_press =lambda x: self.Animatesize(x.parent))
            self.imagescatter.add_widget(image)
            self.container.add_widget(self.imagescatter)
            chooseroot.add_widget(self.container)
            
            if i == 9:
                chooseroot.add_widget(Image(source = hud+"None.png",allow_stretch = True, keep_ratio = False,size_hint_x = None, width = '64dp'))
                
        return choose 

    def Animatesize(self,button):

        print button.parent.pos

        
        anim3 = Animation(x = button.parent.pos[0], d = .75, t = "in_out_back")
        anim3.start(self.medio)
        button.scale = 1.0
        anim1 = Animation(scale = 1.5, d = .05,t = "in_circ")
        anim2 = Animation(scale = 1.0, d = .15,t = "out_circ")
        anim = anim1 + anim2
        anim.start(button)

    def activar_contar(self):
        if self.Tiempo == 0:
            pass
            if self.Contador_state == -1: threading.Timer(1, self.activar_contar).cancel()
        else:
            if self.Contador_state == 1: 
                threading.Timer(1, self.activar_contar).start()
                self.contar()
                self.CalcularTiempo(1)
            
    def contar(self):  
        self.Tiempo -= 1
        self.CalcularTiempo(1)
        if self.dimstate1 == True:
            self.dimstate1 = False
            pass
        else:
            if self.Tiempo == 0: 
                self.Contador_state *= -1
                self.Activar()
                

    def activar_state(self):
        self.Contador_state *= -1
        self.activar_contar()
       
    def AumentarTiempo(self,Plus,button):
        self.Animatesize(button.parent)
        self.Tiempo += Plus
        self.CalcularTiempo(1)
        self.TimeState = self.Tiempo
        print self.Tiempo
    def CalcularTiempo(self,In):
        segundos = (((self.Tiempo/60))%1)*60
        minutos = ((((self.Tiempo/60))/60)%1)*60
        horas = (((((self.Tiempo/60))/60)/60)%1)*60
        #print ("Calculando" + str(self.Tiempo) + " segundos...")

        if segundos< 10: segundos = "0"+ str(segundos)[:-2]
        else: segundos = str(segundos)[:-2]
        if minutos< 10: minutos = "0"+ str(int(minutos))
        else: minutos = str(int(minutos))
        if horas < 10: horas = "0"+ str(int(horas))
        else: horas = str(int(horas))
            
        TimeVar = (str(horas)+":"+str(minutos)+":"+str(segundos))
        #self.Tiempo_text2.text= (C1+str(horas)+":"+str(minutos)+":"+str(segundos))
        self.TextTimerV2.text = (C4+str(horas)+" Horas "+str(minutos)+" Minutos y "+str(segundos))+" segundos"
        #print TimeVar
        cc = 0
        for i in TimeVar: 
            self.l_buttons[cc].text = C4+i
            cc += 1
        #print horas
        #print minutos
        #print segundos
        
        


class MyApp(App):
    def build(self):
        return InterfaceManager()
 

if __name__ in ('__main__', '__android__'):
    MyApp().run()
